/* SPDX-License-Identifier: GPL-3.0-only
 * Ported from MONO2K by Inigo Hernandez, https://github.com/InigoHernandez/mono2k
 * Revision 78d7cdfd676dd8a88a06e6b794fbcfb5fa2b1537, m2k_dsp.c LFO section.
 * Six tracks, three LFOs each, one block per 16 samples at 44100 Hz.
 * Outputs are Q8 RAW parameter deltas; sum first, then clamp raw*256+delta
 * to 0..127*256. Previous block output modulates the next block's controls.
 * Define MML_SIN to an existing donor-compatible sine helper before inclusion
 * to share its table. Caller owns RNG; seed 0x2000 reproduces donor startup.
 */
#ifndef MNM_LFO_H
#define MNM_LFO_H
#include <stdint.h>
#ifndef MNM_NO_LIBC_HEADERS
#include <string.h>
#endif
#define MML_TRACKS 6
#define MML_LFOS 3
#define MML_PARAMS 71
#define MML_MAX_MOD 18
enum { MML_TARGET, MML_DEST, MML_WAVE, MML_TRIG, MML_MULT,
       MML_SPEED, MML_PHASE, MML_DEPTH };
/* DEST raw value -> source raw-parameter index; 255 means disabled. */
static const uint8_t mml_destination[72] = {
    255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70
};
#ifndef MML_SIN
static const int16_t mml_sin_table[1025] = {
    0, 201, 402, 603, 804, 1005, 1206, 1407, 1608, 1809, 2009, 2210,
    2410, 2611, 2811, 3012, 3212, 3412, 3612, 3811, 4011, 4210, 4410, 4609,
    4808, 5007, 5205, 5404, 5602, 5800, 5998, 6195, 6393, 6590, 6786, 6983,
    7179, 7375, 7571, 7767, 7962, 8157, 8351, 8545, 8739, 8933, 9126, 9319,
    9512, 9704, 9896, 10087, 10278, 10469, 10659, 10849, 11039, 11228, 11417, 11605,
    11793, 11980, 12167, 12353, 12539, 12725, 12910, 13094, 13279, 13462, 13645, 13828,
    14010, 14191, 14372, 14553, 14732, 14912, 15090, 15269, 15446, 15623, 15800, 15976,
    16151, 16325, 16499, 16673, 16846, 17018, 17189, 17360, 17530, 17700, 17869, 18037,
    18204, 18371, 18537, 18703, 18868, 19032, 19195, 19357, 19519, 19680, 19841, 20000,
    20159, 20317, 20475, 20631, 20787, 20942, 21096, 21250, 21403, 21554, 21705, 21856,
    22005, 22154, 22301, 22448, 22594, 22739, 22884, 23027, 23170, 23311, 23452, 23592,
    23731, 23870, 24007, 24143, 24279, 24413, 24547, 24680, 24811, 24942, 25072, 25201,
    25329, 25456, 25582, 25708, 25832, 25955, 26077, 26198, 26319, 26438, 26556, 26674,
    26790, 26905, 27019, 27133, 27245, 27356, 27466, 27575, 27683, 27790, 27896, 28001,
    28105, 28208, 28310, 28411, 28510, 28609, 28706, 28803, 28898, 28992, 29085, 29177,
    29268, 29358, 29447, 29534, 29621, 29706, 29791, 29874, 29956, 30037, 30117, 30195,
    30273, 30349, 30424, 30498, 30571, 30643, 30714, 30783, 30852, 30919, 30985, 31050,
    31113, 31176, 31237, 31297, 31356, 31414, 31470, 31526, 31580, 31633, 31685, 31736,
    31785, 31833, 31880, 31926, 31971, 32014, 32057, 32098, 32137, 32176, 32213, 32250,
    32285, 32318, 32351, 32382, 32412, 32441, 32469, 32495, 32521, 32545, 32567, 32589,
    32609, 32628, 32646, 32663, 32678, 32692, 32705, 32717, 32728, 32737, 32745, 32752,
    32757, 32761, 32765, 32766, 32767, 32766, 32765, 32761, 32757, 32752, 32745, 32737,
    32728, 32717, 32705, 32692, 32678, 32663, 32646, 32628, 32609, 32589, 32567, 32545,
    32521, 32495, 32469, 32441, 32412, 32382, 32351, 32318, 32285, 32250, 32213, 32176,
    32137, 32098, 32057, 32014, 31971, 31926, 31880, 31833, 31785, 31736, 31685, 31633,
    31580, 31526, 31470, 31414, 31356, 31297, 31237, 31176, 31113, 31050, 30985, 30919,
    30852, 30783, 30714, 30643, 30571, 30498, 30424, 30349, 30273, 30195, 30117, 30037,
    29956, 29874, 29791, 29706, 29621, 29534, 29447, 29358, 29268, 29177, 29085, 28992,
    28898, 28803, 28706, 28609, 28510, 28411, 28310, 28208, 28105, 28001, 27896, 27790,
    27683, 27575, 27466, 27356, 27245, 27133, 27019, 26905, 26790, 26674, 26556, 26438,
    26319, 26198, 26077, 25955, 25832, 25708, 25582, 25456, 25329, 25201, 25072, 24942,
    24811, 24680, 24547, 24413, 24279, 24143, 24007, 23870, 23731, 23592, 23452, 23311,
    23170, 23027, 22884, 22739, 22594, 22448, 22301, 22154, 22005, 21856, 21705, 21554,
    21403, 21250, 21096, 20942, 20787, 20631, 20475, 20317, 20159, 20000, 19841, 19680,
    19519, 19357, 19195, 19032, 18868, 18703, 18537, 18371, 18204, 18037, 17869, 17700,
    17530, 17360, 17189, 17018, 16846, 16673, 16499, 16325, 16151, 15976, 15800, 15623,
    15446, 15269, 15090, 14912, 14732, 14553, 14372, 14191, 14010, 13828, 13645, 13462,
    13279, 13094, 12910, 12725, 12539, 12353, 12167, 11980, 11793, 11605, 11417, 11228,
    11039, 10849, 10659, 10469, 10278, 10087, 9896, 9704, 9512, 9319, 9126, 8933,
    8739, 8545, 8351, 8157, 7962, 7767, 7571, 7375, 7179, 6983, 6786, 6590,
    6393, 6195, 5998, 5800, 5602, 5404, 5205, 5007, 4808, 4609, 4410, 4210,
    4011, 3811, 3612, 3412, 3212, 3012, 2811, 2611, 2410, 2210, 2009, 1809,
    1608, 1407, 1206, 1005, 804, 603, 402, 201, 0, -201, -402, -603,
    -804, -1005, -1206, -1407, -1608, -1809, -2009, -2210, -2410, -2611, -2811, -3012,
    -3212, -3412, -3612, -3811, -4011, -4210, -4410, -4609, -4808, -5007, -5205, -5404,
    -5602, -5800, -5998, -6195, -6393, -6590, -6786, -6983, -7179, -7375, -7571, -7767,
    -7962, -8157, -8351, -8545, -8739, -8933, -9126, -9319, -9512, -9704, -9896, -10087,
    -10278, -10469, -10659, -10849, -11039, -11228, -11417, -11605, -11793, -11980, -12167, -12353,
    -12539, -12725, -12910, -13094, -13279, -13462, -13645, -13828, -14010, -14191, -14372, -14553,
    -14732, -14912, -15090, -15269, -15446, -15623, -15800, -15976, -16151, -16325, -16499, -16673,
    -16846, -17018, -17189, -17360, -17530, -17700, -17869, -18037, -18204, -18371, -18537, -18703,
    -18868, -19032, -19195, -19357, -19519, -19680, -19841, -20000, -20159, -20317, -20475, -20631,
    -20787, -20942, -21096, -21250, -21403, -21554, -21705, -21856, -22005, -22154, -22301, -22448,
    -22594, -22739, -22884, -23027, -23170, -23311, -23452, -23592, -23731, -23870, -24007, -24143,
    -24279, -24413, -24547, -24680, -24811, -24942, -25072, -25201, -25329, -25456, -25582, -25708,
    -25832, -25955, -26077, -26198, -26319, -26438, -26556, -26674, -26790, -26905, -27019, -27133,
    -27245, -27356, -27466, -27575, -27683, -27790, -27896, -28001, -28105, -28208, -28310, -28411,
    -28510, -28609, -28706, -28803, -28898, -28992, -29085, -29177, -29268, -29358, -29447, -29534,
    -29621, -29706, -29791, -29874, -29956, -30037, -30117, -30195, -30273, -30349, -30424, -30498,
    -30571, -30643, -30714, -30783, -30852, -30919, -30985, -31050, -31113, -31176, -31237, -31297,
    -31356, -31414, -31470, -31526, -31580, -31633, -31685, -31736, -31785, -31833, -31880, -31926,
    -31971, -32014, -32057, -32098, -32137, -32176, -32213, -32250, -32285, -32318, -32351, -32382,
    -32412, -32441, -32469, -32495, -32521, -32545, -32567, -32589, -32609, -32628, -32646, -32663,
    -32678, -32692, -32705, -32717, -32728, -32737, -32745, -32752, -32757, -32761, -32765, -32766,
    -32767, -32766, -32765, -32761, -32757, -32752, -32745, -32737, -32728, -32717, -32705, -32692,
    -32678, -32663, -32646, -32628, -32609, -32589, -32567, -32545, -32521, -32495, -32469, -32441,
    -32412, -32382, -32351, -32318, -32285, -32250, -32213, -32176, -32137, -32098, -32057, -32014,
    -31971, -31926, -31880, -31833, -31785, -31736, -31685, -31633, -31580, -31526, -31470, -31414,
    -31356, -31297, -31237, -31176, -31113, -31050, -30985, -30919, -30852, -30783, -30714, -30643,
    -30571, -30498, -30424, -30349, -30273, -30195, -30117, -30037, -29956, -29874, -29791, -29706,
    -29621, -29534, -29447, -29358, -29268, -29177, -29085, -28992, -28898, -28803, -28706, -28609,
    -28510, -28411, -28310, -28208, -28105, -28001, -27896, -27790, -27683, -27575, -27466, -27356,
    -27245, -27133, -27019, -26905, -26790, -26674, -26556, -26438, -26319, -26198, -26077, -25955,
    -25832, -25708, -25582, -25456, -25329, -25201, -25072, -24942, -24811, -24680, -24547, -24413,
    -24279, -24143, -24007, -23870, -23731, -23592, -23452, -23311, -23170, -23027, -22884, -22739,
    -22594, -22448, -22301, -22154, -22005, -21856, -21705, -21554, -21403, -21250, -21096, -20942,
    -20787, -20631, -20475, -20317, -20159, -20000, -19841, -19680, -19519, -19357, -19195, -19032,
    -18868, -18703, -18537, -18371, -18204, -18037, -17869, -17700, -17530, -17360, -17189, -17018,
    -16846, -16673, -16499, -16325, -16151, -15976, -15800, -15623, -15446, -15269, -15090, -14912,
    -14732, -14553, -14372, -14191, -14010, -13828, -13645, -13462, -13279, -13094, -12910, -12725,
    -12539, -12353, -12167, -11980, -11793, -11605, -11417, -11228, -11039, -10849, -10659, -10469,
    -10278, -10087, -9896, -9704, -9512, -9319, -9126, -8933, -8739, -8545, -8351, -8157,
    -7962, -7767, -7571, -7375, -7179, -6983, -6786, -6590, -6393, -6195, -5998, -5800,
    -5602, -5404, -5205, -5007, -4808, -4609, -4410, -4210, -4011, -3811, -3612, -3412,
    -3212, -3012, -2811, -2611, -2410, -2210, -2009, -1809, -1608, -1407, -1206, -1005,
    -804, -603, -402, -201, 0,
};
static inline int32_t mml_sine(uint32_t phase)
{
    uint32_t i=phase>>22, f=(phase>>6)&65535u;
    int32_t a=mml_sin_table[i], b=mml_sin_table[i+1];
    return a+(((b-a)*(int32_t)f)>>16);
}
#define MML_SIN mml_sine
#endif
typedef struct {
    uint32_t phase;
    int32_t value, hold, random;
    uint8_t done;
} mml_voice;
typedef struct { uint8_t track, param; int32_t value; } mml_mod;
typedef struct {
    mml_voice voice[MML_TRACKS][MML_LFOS];
    mml_mod mod[MML_MAX_MOD];
    uint8_t count;
} mml_state;
static inline void mml_init(mml_state *s) { memset(s,0,sizeof(*s)); }
static inline int32_t mml_delta(const mml_state *s, unsigned track, unsigned param)
{
    for(unsigned i=0;i<s->count;++i)
        if(s->mod[i].track==track && s->mod[i].param==param) return s->mod[i].value;
    return 0;
}
static inline int32_t mml_shape(unsigned wave, uint32_t phase, int32_t random)
{
    int32_t x=(int32_t)(phase>>16);
    switch(wave) {
    case 0: return x<32768 ? x*2-32768 : (65535-x)*2-32768;
    case 1: return MML_SIN(phase);
    case 2: return phase<0x80000000u ? 32767 : -32767;
    case 3: return 32767-x;
    case 4: { uint32_t y=65535u-(uint32_t)x; y=(y*y)>>16; y=(y*y)>>16; return (int32_t)(y>>1); }
    case 5: return x>>1;
    default: return random;
    }
}
static inline uint32_t mml_random(uint32_t *rng)
{
    *rng ^= *rng<<13; *rng ^= *rng>>17; *rng ^= *rng<<5;
    return *rng;
}
/* raw controls must be 0..127; trigger applies to one track's three LFOs.
 * FREE continues, TRIG/ONE/HALF reset to PHASE, HOLD samples current waveform.
 * A skipped source LFO trigger means the caller simply omits this call. */
static inline void mml_trigger(mml_state *s, unsigned track, const uint8_t raw[3][8])
{
    if(track>=MML_TRACKS) return;
    for(unsigned l=0;l<MML_LFOS;++l) {
        mml_voice *v=&s->voice[track][l];
        unsigned trig=(raw[l][MML_TRIG]*5u)>>7;
        if(!trig) continue;
        if(trig==2) { v->hold=mml_shape((raw[l][MML_WAVE]*7u)>>7,v->phase,v->random); continue; }
        v->phase=(uint32_t)raw[l][MML_PHASE]<<25;
        v->done=0;
    }
}
static inline int mml_control(const mml_state *s, unsigned t, unsigned l, unsigned p, uint8_t raw)
{
    int32_t q=(int32_t)raw*256+mml_delta(s,t,42+l*8+p);
    return q<0 ? 0 : q>127*256 ? 127 : q>>8;
}
/* Resolve the preceding block once, rather than scanning its sparse list for
 * each of seven controls of every LFO. Outputs targeting synth/FX parameters
 * cannot affect this table. Preserve mml_delta's first-match semantics. */
static inline void mml_controls(const mml_state *s,const uint8_t raw[6][3][8],
                                uint8_t effective[6][3][8])
{
    memcpy(effective,raw,MML_TRACKS*MML_LFOS*8u);
    for(unsigned i=s->count;i>0;--i){
        const mml_mod *m=&s->mod[i-1];
        if(m->track>=MML_TRACKS||m->param<42||m->param>=66)continue;
        unsigned l=(m->param-42)/8,p=(m->param-42)%8;
        int32_t q=(int32_t)raw[m->track][l][p]*256+m->value;
        effective[m->track][l][p]=(uint8_t)(q<0?0:q>127*256?127:q>>8);
    }
}
/* All tracks must be evaluated together, preserving one-block cross modulation.
 * bpm10 is tempo in tenths of BPM (1200 = 120 BPM); unsigned arithmetic wraps
 * exactly like the donor at extreme speed/multiplier/tempo. view_track selects
 * the waveform monitor even at zero depth; use -1 when no monitor is needed.
 * Output s->mod[0..count) replaces the previous output, never accumulates stale
 * destinations. Trigger before this call when the sequencer triggers a note. */
static inline void mml_block(mml_state *s, const uint8_t raw[6][3][8],
                             uint32_t bpm10, uint32_t *rng, int view_track)
{
    mml_mod next[MML_MAX_MOD];
    unsigned count=0;
    uint8_t effective[MML_TRACKS][MML_LFOS][8];
    mml_controls(s,raw,effective);
    for(unsigned t=0;t<MML_TRACKS;++t) for(unsigned l=0;l<MML_LFOS;++l) {
        mml_voice *v=&s->voice[t][l];
        int dest=effective[t][l][MML_DEST];
        if(dest==0 || dest>MML_PARAMS) { v->value=0; continue; }
        unsigned wave=(effective[t][l][MML_WAVE]*7u)>>7;
        unsigned trig=(effective[t][l][MML_TRIG]*5u)>>7;
        unsigned mult=1u<<((effective[t][l][MML_MULT]*8u)>>7);
        uint32_t inc=(uint32_t)effective[t][l][MML_SPEED]*mult*bpm10*10u;
        uint32_t before=v->phase;
        if(!v->done) {
            v->phase+=inc;
            if(v->phase<before) v->random=(int32_t)(mml_random(rng)>>16)-32768;
            if(trig>=3) {
                uint32_t start=(uint32_t)raw[t][l][MML_PHASE]<<25;
                uint32_t a=before-start, z=v->phase-start;
                if(trig==3 && z<a) {v->done=1;v->phase=start-1u;}
                if(trig==4 && z>=0x80000000u && a<0x80000000u) {v->done=1;v->phase=start+0x80000000u;}
            }
        }
        int depth=effective[t][l][MML_DEPTH]-64;
        if(!depth && (int)t!=view_track) {v->value=0;continue;}
        v->value=trig==2 ? v->hold : mml_shape(wave,v->phase,v->random);
        if(depth) {
            unsigned target=(effective[t][l][MML_TARGET]*6u)>>7;
            unsigned param=mml_destination[dest], i=0;
            int32_t value=(v->value*depth)>>6;
            for(;i<count;++i) if(next[i].track==target && next[i].param==param) break;
            if(i==count) next[count++]=(mml_mod){(uint8_t)target,(uint8_t)param,0};
            next[i].value+=value;
        }
    }
    for(unsigned i=0;i<count;++i) s->mod[i]=next[i];
    s->count=(uint8_t)count;
}
#endif
